# devtools::create_package("path/to/yourpackage")
rm(list = c("nemenyi_test", "nemenyi_test_and_plot", "nemenyi_test_and_plot_as_rows", "plot_nemenyi"))
devtools::test()
# devtools::check()
devtools::document()

devtools::install()
devtools::build(path="build", manual = T)
# install.packages("build/NemenyiPlot_0.1.0.tar.gz")

library(NemenyiPlot)

cd = 1

means = c(1, 1.01, 1.2, 3, 3.2, 3.5, 3.5, 3.5, 3.5, 6, 7)

labels = c(
  "Method E",
  "Method K",
  "Method D",
  "Method B",
  "Method C",
  "Method J",
  "Method A",
  "Method G",
  "Method I",
  "Method F",
  "Method H"
)

?NemenyiPlot::plot_nemenyi
?NemenyiPlot::nemenyi_test_and_plot
NemenyiPlot::plot_nemenyi(means, labels, cd)
NemenyiPlot::plot_nemenyi(means, labels, cd, reversed_ruler = T, dots_size = 0)
NemenyiPlot::plot_nemenyi(means, labels, cd, vertical = T, show_means = T)
NemenyiPlot::plot_nemenyi(means, labels, cd, vertical = T, reversed_ruler = T, color_ties = F)

